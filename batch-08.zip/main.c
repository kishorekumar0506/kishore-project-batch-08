#include <stdio.h>
#include <wiringPi.h>

#define GAS_SENSOR_PIN 0 // GPIO pin for the gas sensor (adjust as per your setup)

int main() {
    // Initialize wiringPi library
    if (wiringPiSetup() == -1) {
        printf("WiringPi setup failed!\n");
        return 1; // Exit if wiringPi setup fails
    }

    // Setup the sensor pin as input
    pinMode(GAS_SENSOR_PIN, INPUT);

    while (1) {
        int gasLevel = analogRead(GAS_SENSOR_PIN); // Read the gas level from the sensor
        printf("Gas Level: %d\n", gasLevel); // Print the gas level value
        delay(1000); // Delay for 1 second
    }

    return 0;
}
